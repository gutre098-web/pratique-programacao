# 📚 Pratique - Programação (Universidade Anhembi Morumbi)

Este repositório contém a solução da atividade **Pratique - Imersão Digital**, desenvolvida em **Java**.  
O sistema simula o **gerenciamento de eventos**, permitindo cadastrar, listar, salvar e carregar eventos.

---

## 📂 Estrutura do projeto
```
src/
 ├── Evento.java
 ├── GerenciadorEventos.java
 └── Main.java
```

- **Evento.java** → Classe que representa um evento (id, nome, descrição, local, data/hora).  
- **GerenciadorEventos.java** → Classe que gerencia os eventos (cadastrar, listar, salvar em arquivo, carregar do arquivo).  
- **Main.java** → Classe principal com o menu no console para interação com o usuário.  

---

## 🚀 Como executar
1. Clone este repositório:
   ```bash
   git clone https://github.com/SEU-USUARIO/pratique-programacao.git
   ```
2. Abra o projeto em uma IDE Java (Eclipse, IntelliJ ou Replit).  
3. Compile e execute a classe **Main.java**.  
4. Utilize o menu exibido no console:  
   - `1 - Cadastrar evento`  
   - `2 - Listar todos os eventos`  
   - `3 - Listar eventos futuros`  
   - `4 - Listar eventos passados`  
   - `5 - Salvar em arquivo`  
   - `0 - Sair`  

---

## 📌 Funcionalidades
✅ Cadastrar eventos com nome, descrição, local e data/hora.  
✅ Listar todos os eventos cadastrados.  
✅ Listar apenas eventos **futuros**.  
✅ Listar apenas eventos **passados**.  
✅ Salvar e carregar eventos de um arquivo `eventos.txt`.  

---

👨‍💻 Desenvolvido como parte da atividade **Pratique - Universidade Anhembi Morumbi**.
