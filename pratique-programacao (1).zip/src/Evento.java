import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Evento {
    private int id;
    private String nome;
    private String descricao;
    private String local;
    private LocalDateTime dataHora;

    public Evento(int id, String nome, String descricao, String local, LocalDateTime dataHora) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.local = local;
        this.dataHora = dataHora;
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "ID: " + id + " | " + nome + " - " + descricao + 
               " | Local: " + local + " | Data: " + dataHora.format(formatter);
    }

    public String toFile() {
        return id + ";" + nome + ";" + descricao + ";" + local + ";" + dataHora.toString();
    }

    public static Evento fromFile(String line) {
        String[] parts = line.split(";");
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        String descricao = parts[2];
        String local = parts[3];
        LocalDateTime dataHora = LocalDateTime.parse(parts[4]);
        return new Evento(id, nome, descricao, local, dataHora);
    }
}
