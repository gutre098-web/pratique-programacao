import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GerenciadorEventos gerenciador = new GerenciadorEventos();
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        gerenciador.carregarDeArquivo();

        int opcao;
        do {
            System.out.println("\n==== MENU ====");
            System.out.println("1 - Cadastrar evento");
            System.out.println("2 - Listar todos os eventos");
            System.out.println("3 - Listar eventos futuros");
            System.out.println("4 - Listar eventos passados");
            System.out.println("5 - Salvar em arquivo");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine(); // consumir enter

            switch (opcao) {
                case 1:
                    System.out.print("Nome do evento: ");
                    String nome = sc.nextLine();
                    System.out.print("Descrição: ");
                    String descricao = sc.nextLine();
                    System.out.print("Local: ");
                    String local = sc.nextLine();
                    System.out.print("Data e hora (dd/MM/yyyy HH:mm): ");
                    String dataHoraStr = sc.nextLine();
                    LocalDateTime dataHora = LocalDateTime.parse(dataHoraStr, formatter);
                    gerenciador.cadastrarEvento(nome, descricao, local, dataHora);
                    break;
                case 2:
                    gerenciador.listarEventos();
                    break;
                case 3:
                    gerenciador.listarEventosFuturos();
                    break;
                case 4:
                    gerenciador.listarEventosPassados();
                    break;
                case 5:
                    gerenciador.salvarEmArquivo();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);

        sc.close();
    }
}
