import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class GerenciadorEventos {
    private List<Evento> eventos = new ArrayList<>();
    private int proximoId = 1;

    public void cadastrarEvento(String nome, String descricao, String local, LocalDateTime dataHora) {
        Evento evento = new Evento(proximoId++, nome, descricao, local, dataHora);
        eventos.add(evento);
        System.out.println("Evento cadastrado com sucesso!");
    }

    public void listarEventos() {
        if (eventos.isEmpty()) {
            System.out.println("Nenhum evento cadastrado.");
        } else {
            eventos.forEach(System.out::println);
        }
    }

    public void listarEventosFuturos() {
        eventos.stream()
            .filter(e -> e.getDataHora().isAfter(LocalDateTime.now()))
            .sorted(Comparator.comparing(Evento::getDataHora))
            .forEach(System.out::println);
    }

    public void listarEventosPassados() {
        eventos.stream()
            .filter(e -> e.getDataHora().isBefore(LocalDateTime.now()))
            .sorted(Comparator.comparing(Evento::getDataHora))
            .forEach(System.out::println);
    }

    public void salvarEmArquivo() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("eventos.txt"))) {
            for (Evento e : eventos) {
                writer.println(e.toFile());
            }
            System.out.println("Eventos salvos em arquivo.");
        } catch (IOException e) {
            System.out.println("Erro ao salvar arquivo: " + e.getMessage());
        }
    }

    public void carregarDeArquivo() {
        try (BufferedReader reader = new BufferedReader(new FileReader("eventos.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Evento evento = Evento.fromFile(line);
                eventos.add(evento);
                proximoId = Math.max(proximoId, evento.getId() + 1);
            }
            System.out.println("Eventos carregados do arquivo.");
        } catch (IOException e) {
            System.out.println("Nenhum arquivo encontrado. Começando vazio.");
        }
    }
}
